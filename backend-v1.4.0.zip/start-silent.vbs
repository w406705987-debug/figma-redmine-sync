Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "F:\vs\figma-redmine-sync\backend\"
WshShell.Run "cmd /c node server.js", 0, False
